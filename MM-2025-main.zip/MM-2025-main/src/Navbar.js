import React from "react";
import { Header } from "./Navbar.style";
import { CDBNavbar, CDBInput } from "cdbreact";

const Navbar = () => {

	return (
        <Header style={{background:"#333", color:"#fff"}}>
          
        </Header>
	);
}

export default Navbar;
