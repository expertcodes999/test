
import explosion1  from '../assets/images/playpage/newExplosion/1.png'
import explosion2  from '../assets/images/playpage/newExplosion/2.png'
import explosion3  from '../assets/images/playpage/newExplosion/3.png'
import explosion4  from '../assets/images/playpage/newExplosion/4.png'
import explosion5  from '../assets/images/playpage/newExplosion/5.png'
import explosion6  from '../assets/images/playpage/newExplosion/6.png'
import explosion7  from '../assets/images/playpage/newExplosion/7.png'
import explosion8  from '../assets/images/playpage/newExplosion/8.png'
import explosion9  from '../assets/images/playpage/newExplosion/9.png'
import explosion10  from '../assets/images/playpage/newExplosion/10.png'
import explosion11  from '../assets/images/playpage/newExplosion/11.png'
import explosion12  from '../assets/images/playpage/newExplosion/12.png'
import explosion13  from '../assets/images/playpage/newExplosion/13.png'
import explosion14  from '../assets/images/playpage/newExplosion/14.png'
import explosion15  from '../assets/images/playpage/newExplosion/15.png'
import explosion16  from '../assets/images/playpage/newExplosion/16.png'
import explosion17  from '../assets/images/playpage/newExplosion/17.png'
import explosion18  from '../assets/images/playpage/newExplosion/18.png'
import explosion19  from '../assets/images/playpage/newExplosion/19.png'
import explosion20  from '../assets/images/playpage/newExplosion/20.png'
import explosion21  from '../assets/images/playpage/newExplosion/21.png'
import explosion22  from '../assets/images/playpage/newExplosion/22.png'
import explosion23  from '../assets/images/playpage/newExplosion/23.png'
import explosion24  from '../assets/images/playpage/newExplosion/24.png'
import explosion25  from '../assets/images/playpage/newExplosion/25.png'
import explosion26  from '../assets/images/playpage/newExplosion/26.png'
import explosion27  from '../assets/images/playpage/newExplosion/27.png'
import explosion28  from '../assets/images/playpage/newExplosion/28.png'
import explosion29  from '../assets/images/playpage/newExplosion/29.png'
import explosion30  from '../assets/images/playpage/newExplosion/30.png'
import explosion31  from '../assets/images/playpage/newExplosion/31.png'
import explosion32  from '../assets/images/playpage/newExplosion/32.png'
import explosion33  from '../assets/images/playpage/newExplosion/33.png'
import explosion34  from '../assets/images/playpage/newExplosion/34.png'
import explosion35  from '../assets/images/playpage/newExplosion/35.png'
import explosion36  from '../assets/images/playpage/newExplosion/36.png'
import explosion37  from '../assets/images/playpage/newExplosion/37.png'
import explosion38  from '../assets/images/playpage/newExplosion/38.png'
import explosion39  from '../assets/images/playpage/newExplosion/39.png'
import explosion40  from '../assets/images/playpage/newExplosion/40.png'
import explosion41  from '../assets/images/playpage/newExplosion/41.png'
import explosion42  from '../assets/images/playpage/newExplosion/42.png'
import explosion43  from '../assets/images/playpage/newExplosion/43.png'
import explosion44  from '../assets/images/playpage/newExplosion/44.png'
import explosion45  from '../assets/images/playpage/newExplosion/45.png'
import explosion46  from '../assets/images/playpage/newExplosion/46.png'
import explosion47  from '../assets/images/playpage/newExplosion/47.png'
import explosion48  from '../assets/images/playpage/newExplosion/48.png'
import explosion49  from '../assets/images/playpage/newExplosion/49.png'
import explosion50  from '../assets/images/playpage/newExplosion/50.png'
import explosion51  from '../assets/images/playpage/newExplosion/51.png'
import explosion52  from '../assets/images/playpage/newExplosion/52.png'
import explosion53  from '../assets/images/playpage/newExplosion/53.png'
import explosion54  from '../assets/images/playpage/newExplosion/54.png'
import explosion55  from '../assets/images/playpage/newExplosion/55.png'
import explosion56  from '../assets/images/playpage/newExplosion/56.png'
import explosion57  from '../assets/images/playpage/newExplosion/57.png'
import explosion58  from '../assets/images/playpage/newExplosion/58.png'
import explosion59  from '../assets/images/playpage/newExplosion/59.png'
import explosion60  from '../assets/images/playpage/newExplosion/60.png'
import explosion61  from '../assets/images/playpage/newExplosion/61.png'
import explosion62  from '../assets/images/playpage/newExplosion/62.png'
import explosion63  from '../assets/images/playpage/newExplosion/63.png'
import explosion64  from '../assets/images/playpage/newExplosion/64.png'
import explosion65  from '../assets/images/playpage/newExplosion/65.png'
import explosion66  from '../assets/images/playpage/newExplosion/66.png'
import explosion67  from '../assets/images/playpage/newExplosion/67.png'
import explosion68  from '../assets/images/playpage/newExplosion/68.png'
import explosion69  from '../assets/images/playpage/newExplosion/69.png'
import explosion70  from '../assets/images/playpage/newExplosion/70.png'
import explosion71  from '../assets/images/playpage/newExplosion/71.png'
import explosion72  from '../assets/images/playpage/newExplosion/72.png'
import explosion73  from '../assets/images/playpage/newExplosion/73.png'
import explosion74  from '../assets/images/playpage/newExplosion/74.png'
import explosion75  from '../assets/images/playpage/newExplosion/75.png'
import explosion76  from '../assets/images/playpage/newExplosion/76.png'
import explosion77  from '../assets/images/playpage/newExplosion/77.png'
import explosion78  from '../assets/images/playpage/newExplosion/78.png'
import explosion79  from '../assets/images/playpage/newExplosion/79.png'
import explosion80  from '../assets/images/playpage/newExplosion/80.png'
import explosion81  from '../assets/images/playpage/newExplosion/81.png'
import explosion82  from '../assets/images/playpage/newExplosion/82.png'
import explosion83  from '../assets/images/playpage/newExplosion/83.png'
import explosion84  from '../assets/images/playpage/newExplosion/84.png'
import explosion85  from '../assets/images/playpage/newExplosion/85.png'
import explosion86  from '../assets/images/playpage/newExplosion/86.png'
import explosion87  from '../assets/images/playpage/newExplosion/87.png'
import explosion88  from '../assets/images/playpage/newExplosion/88.png'
import explosion89  from '../assets/images/playpage/newExplosion/89.png'
import explosion90  from '../assets/images/playpage/newExplosion/90.png'
import explosion91  from '../assets/images/playpage/newExplosion/91.png'
import explosion92  from '../assets/images/playpage/newExplosion/92.png'
import explosion93  from '../assets/images/playpage/newExplosion/93.png'
import explosion94  from '../assets/images/playpage/newExplosion/94.png'
import explosion95  from '../assets/images/playpage/newExplosion/95.png'
import explosion96  from '../assets/images/playpage/newExplosion/96.png'
import explosion97  from '../assets/images/playpage/newExplosion/97.png'
import explosion98  from '../assets/images/playpage/newExplosion/98.png'
import explosion99  from '../assets/images/playpage/newExplosion/99.png'
import explosion100 from '../assets/images/playpage/newExplosion/100.png'
import explosion101 from '../assets/images/playpage/newExplosion/101.png'
import explosion102 from '../assets/images/playpage/newExplosion/102.png'
import explosion103 from '../assets/images/playpage/newExplosion/103.png'
import explosion104 from '../assets/images/playpage/newExplosion/104.png'
import explosion105 from '../assets/images/playpage/newExplosion/105.png'
import explosion106 from '../assets/images/playpage/newExplosion/106.png'
import explosion107 from '../assets/images/playpage/newExplosion/107.png'
import explosion108 from '../assets/images/playpage/newExplosion/108.png'
import explosion109 from '../assets/images/playpage/newExplosion/109.png'
import explosion110 from '../assets/images/playpage/newExplosion/110.png'
import explosion111 from '../assets/images/playpage/newExplosion/111.png'
import explosion112 from '../assets/images/playpage/newExplosion/112.png'
import explosion113 from '../assets/images/playpage/newExplosion/113.png'
import explosion114 from '../assets/images/playpage/newExplosion/114.png'
import explosion115 from '../assets/images/playpage/newExplosion/115.png'
import explosion116 from '../assets/images/playpage/newExplosion/116.png'
import explosion117 from '../assets/images/playpage/newExplosion/117.png'
import explosion118 from '../assets/images/playpage/newExplosion/118.png'
import explosion119 from '../assets/images/playpage/newExplosion/119.png'
import explosion120 from '../assets/images/playpage/newExplosion/120.png'
import explosion121 from '../assets/images/playpage/newExplosion/121.png'
import explosion122 from '../assets/images/playpage/newExplosion/122.png'
import explosion123 from '../assets/images/playpage/newExplosion/123.png'
import explosion124 from '../assets/images/playpage/newExplosion/124.png'
import explosion125 from '../assets/images/playpage/newExplosion/125.png'
import explosion126 from '../assets/images/playpage/newExplosion/126.png'
import explosion127 from '../assets/images/playpage/newExplosion/127.png'
import explosion128 from '../assets/images/playpage/newExplosion/128.png'
import explosion129 from '../assets/images/playpage/newExplosion/129.png'
import explosion130 from '../assets/images/playpage/newExplosion/130.png'
import explosion131 from '../assets/images/playpage/newExplosion/131.png'
import explosion132 from '../assets/images/playpage/newExplosion/132.png'
import explosion133 from '../assets/images/playpage/newExplosion/133.png'
import explosion134 from '../assets/images/playpage/newExplosion/134.png'
import explosion135 from '../assets/images/playpage/newExplosion/135.png'
import explosion136 from '../assets/images/playpage/newExplosion/136.png'
import explosion137 from '../assets/images/playpage/newExplosion/137.png'
import explosion138 from '../assets/images/playpage/newExplosion/138.png'
import explosion139 from '../assets/images/playpage/newExplosion/139.png'
import explosion140 from '../assets/images/playpage/newExplosion/140.png'
import explosion141 from '../assets/images/playpage/newExplosion/141.png'
import explosion142 from '../assets/images/playpage/newExplosion/142.png'
import explosion143 from '../assets/images/playpage/newExplosion/143.png'
import explosion144 from '../assets/images/playpage/newExplosion/144.png'
import explosion145 from '../assets/images/playpage/newExplosion/145.png'
import explosion146 from '../assets/images/playpage/newExplosion/146.png'
import explosion147 from '../assets/images/playpage/newExplosion/147.png'
import explosion148 from '../assets/images/playpage/newExplosion/148.png'
import explosion149 from '../assets/images/playpage/newExplosion/149.png'
import explosion150 from '../assets/images/playpage/newExplosion/150.png'
import explosion151 from '../assets/images/playpage/newExplosion/151.png'
import explosion152 from '../assets/images/playpage/newExplosion/152.png'
import explosion153 from '../assets/images/playpage/newExplosion/153.png'
import explosion154 from '../assets/images/playpage/newExplosion/154.png'
import explosion155 from '../assets/images/playpage/newExplosion/155.png'
import explosion156 from '../assets/images/playpage/newExplosion/156.png'
import explosion157 from '../assets/images/playpage/newExplosion/157.png'
import explosion158 from '../assets/images/playpage/newExplosion/158.png'
import explosion159 from '../assets/images/playpage/newExplosion/159.png'
import explosion160 from '../assets/images/playpage/newExplosion/160.png'
import explosion161 from '../assets/images/playpage/newExplosion/161.png'
import explosion162 from '../assets/images/playpage/newExplosion/162.png'
import explosion163 from '../assets/images/playpage/newExplosion/163.png'
import explosion164 from '../assets/images/playpage/newExplosion/164.png'
import explosion165 from '../assets/images/playpage/newExplosion/165.png'
import explosion166 from '../assets/images/playpage/newExplosion/166.png'
import explosion167 from '../assets/images/playpage/newExplosion/167.png'
import explosion168 from '../assets/images/playpage/newExplosion/168.png'

import rocket1  from '../assets/images/playpage/rocketAnimation/1.png'
import rocket2  from '../assets/images/playpage/rocketAnimation/2.png'
import rocket3  from '../assets/images/playpage/rocketAnimation/3.png'
import rocket4  from '../assets/images/playpage/rocketAnimation/4.png'
import rocket5  from '../assets/images/playpage/rocketAnimation/5.png'
import rocket6  from '../assets/images/playpage/rocketAnimation/6.png'
import rocket7  from '../assets/images/playpage/rocketAnimation/7.png'
import rocket8  from '../assets/images/playpage/rocketAnimation/8.png'
import rocket9  from '../assets/images/playpage/rocketAnimation/9.png'
import rocket10  from '../assets/images/playpage/rocketAnimation/10.png'
import rocket11  from '../assets/images/playpage/rocketAnimation/11.png'
import rocket12  from '../assets/images/playpage/rocketAnimation/12.png'
import rocket13  from '../assets/images/playpage/rocketAnimation/13.png'
import rocket14  from '../assets/images/playpage/rocketAnimation/14.png'
import rocket15  from '../assets/images/playpage/rocketAnimation/15.png'
import rocket16  from '../assets/images/playpage/rocketAnimation/16.png'
import rocket17  from '../assets/images/playpage/rocketAnimation/17.png'
import rocket18  from '../assets/images/playpage/rocketAnimation/18.png'
import rocket19  from '../assets/images/playpage/rocketAnimation/19.png'
import rocket20  from '../assets/images/playpage/rocketAnimation/20.png'
import rocket21  from '../assets/images/playpage/rocketAnimation/21.png'
import rocket22  from '../assets/images/playpage/rocketAnimation/22.png'
import rocket23  from '../assets/images/playpage/rocketAnimation/23.png'
import rocket24  from '../assets/images/playpage/rocketAnimation/24.png'
import rocket25  from '../assets/images/playpage/rocketAnimation/25.png'
import rocket26  from '../assets/images/playpage/rocketAnimation/26.png'
import rocket27  from '../assets/images/playpage/rocketAnimation/27.png'
import rocket28  from '../assets/images/playpage/rocketAnimation/28.png'
import rocket29  from '../assets/images/playpage/rocketAnimation/29.png'
import rocket30  from '../assets/images/playpage/rocketAnimation/30.png'
// import rocket31  from '../assets/images/playpage/rocketAnimation/31.png'
// import rocket32  from '../assets/images/playpage/rocketAnimation/32.png'
// import rocket33  from '../assets/images/playpage/rocketAnimation/33.png'
// import rocket34  from '../assets/images/playpage/rocketAnimation/34.png'
// import rocket35  from '../assets/images/playpage/rocketAnimation/35.png'
// import rocket36  from '../assets/images/playpage/rocketAnimation/36.png'
// import rocket37  from '../assets/images/playpage/rocketAnimation/37.png'
// import rocket38  from '../assets/images/playpage/rocketAnimation/38.png'
// import rocket39  from '../assets/images/playpage/rocketAnimation/39.png'
// import rocket40  from '../assets/images/playpage/rocketAnimation/40.png'
// import rocket41  from '../assets/images/playpage/rocketAnimation/41.png'
// import rocket42  from '../assets/images/playpage/rocketAnimation/42.png'
// import rocket43  from '../assets/images/playpage/rocketAnimation/43.png'
// import rocket44  from '../assets/images/playpage/rocketAnimation/44.png'
// import rocket45  from '../assets/images/playpage/rocketAnimation/45.png'
// import rocket46  from '../assets/images/playpage/rocketAnimation/46.png'
// import rocket47  from '../assets/images/playpage/rocketAnimation/47.png'
// import rocket48  from '../assets/images/playpage/rocketAnimation/48.png'
// import rocket49  from '../assets/images/playpage/rocketAnimation/49.png'
// import rocket50  from '../assets/images/playpage/rocketAnimation/50.png'
// import rocket51  from '../assets/images/playpage/rocketAnimation/51.png'
// import rocket52  from '../assets/images/playpage/rocketAnimation/52.png'
// import rocket53  from '../assets/images/playpage/rocketAnimation/53.png'
// import rocket54  from '../assets/images/playpage/rocketAnimation/54.png'
// import rocket55  from '../assets/images/playpage/rocketAnimation/55.png'
// import rocket56  from '../assets/images/playpage/rocketAnimation/56.png'
// import rocket57  from '../assets/images/playpage/rocketAnimation/57.png'
// import rocket58  from '../assets/images/playpage/rocketAnimation/58.png'
// import rocket59  from '../assets/images/playpage/rocketAnimation/59.png'
// import rocket60  from '../assets/images/playpage/rocketAnimation/60.png'
// import rocket61  from '../assets/images/playpage/rocketAnimation/61.png'

import coinExplosion1  from '../assets/images/blueExplosion/1.png'
import coinExplosion2  from '../assets/images/blueExplosion/2.png'
import coinExplosion3  from '../assets/images/blueExplosion/3.png'
import coinExplosion4  from '../assets/images/blueExplosion/4.png'
import coinExplosion5  from '../assets/images/blueExplosion/5.png'
import coinExplosion6  from '../assets/images/blueExplosion/6.png'
import coinExplosion7  from '../assets/images/blueExplosion/7.png'
import coinExplosion8  from '../assets/images/blueExplosion/8.png'
import coinExplosion9  from '../assets/images/blueExplosion/9.png'
import coinExplosion10  from '../assets/images/blueExplosion/10.png'
import coinExplosion11  from '../assets/images/blueExplosion/11.png'
import coinExplosion12  from '../assets/images/blueExplosion/12.png'
import coinExplosion13  from '../assets/images/blueExplosion/13.png'
import coinExplosion14  from '../assets/images/blueExplosion/14.png'
import coinExplosion15  from '../assets/images/blueExplosion/15.png'
import coinExplosion16  from '../assets/images/blueExplosion/16.png'
import coinExplosion17  from '../assets/images/blueExplosion/17.png'
import coinExplosion18  from '../assets/images/blueExplosion/18.png'
import coinExplosion19  from '../assets/images/blueExplosion/19.png'
import coinExplosion20  from '../assets/images/blueExplosion/20.png'
import coinExplosion21  from '../assets/images/blueExplosion/21.png'
import coinExplosion22  from '../assets/images/blueExplosion/22.png'
import coinExplosion23  from '../assets/images/blueExplosion/23.png'
import coinExplosion24  from '../assets/images/blueExplosion/24.png'
import coinExplosion25  from '../assets/images/blueExplosion/25.png'
import coinExplosion26  from '../assets/images/blueExplosion/26.png'
import coinExplosion27  from '../assets/images/blueExplosion/27.png'
import coinExplosion28  from '../assets/images/blueExplosion/28.png'
import coinExplosion29  from '../assets/images/blueExplosion/29.png'
import coinExplosion30  from '../assets/images/blueExplosion/30.png'
import coinExplosion31  from '../assets/images/blueExplosion/31.png'
import coinExplosion32  from '../assets/images/blueExplosion/32.png'
import coinExplosion33  from '../assets/images/blueExplosion/33.png'
import coinExplosion34  from '../assets/images/blueExplosion/34.png'
import coinExplosion35  from '../assets/images/blueExplosion/35.png'
import coinExplosion36  from '../assets/images/blueExplosion/36.png'
import coinExplosion37  from '../assets/images/blueExplosion/37.png'

import coinSpinning1  from '../assets/images/newCoinspin/1.png'
import coinSpinning2  from '../assets/images/newCoinspin/2.png'
import coinSpinning3  from '../assets/images/newCoinspin/3.png'
import coinSpinning4  from '../assets/images/newCoinspin/4.png'
import coinSpinning5  from '../assets/images/newCoinspin/5.png'
import coinSpinning6  from '../assets/images/newCoinspin/6.png'
import coinSpinning7  from '../assets/images/newCoinspin/7.png'
import coinSpinning8  from '../assets/images/newCoinspin/8.png'
import coinSpinning9  from '../assets/images/newCoinspin/9.png'
import coinSpinning10  from '../assets/images/newCoinspin/10.png'
import coinSpinning11  from '../assets/images/newCoinspin/11.png'
import coinSpinning12  from '../assets/images/newCoinspin/12.png'
import coinSpinning13  from '../assets/images/newCoinspin/13.png'
import coinSpinning14  from '../assets/images/newCoinspin/14.png'
import coinSpinning15  from '../assets/images/newCoinspin/15.png'
import coinSpinning16  from '../assets/images/newCoinspin/16.png'
import coinSpinning17  from '../assets/images/newCoinspin/17.png'
import coinSpinning18  from '../assets/images/newCoinspin/18.png'
import coinSpinning19  from '../assets/images/newCoinspin/19.png'
import coinSpinning20  from '../assets/images/newCoinspin/20.png'
import coinSpinning21  from '../assets/images/newCoinspin/21.png'
import coinSpinning22  from '../assets/images/newCoinspin/22.png'
import coinSpinning23  from '../assets/images/newCoinspin/23.png'
import coinSpinning24  from '../assets/images/newCoinspin/24.png'
import coinSpinning25  from '../assets/images/newCoinspin/25.png'
import coinSpinning26  from '../assets/images/newCoinspin/26.png'
import coinSpinning27  from '../assets/images/newCoinspin/27.png'
import coinSpinning28  from '../assets/images/newCoinspin/28.png'
import coinSpinning29  from '../assets/images/newCoinspin/29.png'
import coinSpinning30  from '../assets/images/newCoinspin/30.png'
import coinSpinning31  from '../assets/images/newCoinspin/31.png'
import coinSpinning32  from '../assets/images/newCoinspin/32.png'
import coinSpinning33  from '../assets/images/newCoinspin/33.png'
import coinSpinning34  from '../assets/images/newCoinspin/34.png'
import coinSpinning35  from '../assets/images/newCoinspin/35.png'
import coinSpinning36  from '../assets/images/newCoinspin/36.png'
import coinSpinning37  from '../assets/images/newCoinspin/37.png'
import coinSpinning38  from '../assets/images/newCoinspin/38.png'
import coinSpinning39  from '../assets/images/newCoinspin/39.png'
import coinSpinning40  from '../assets/images/newCoinspin/40.png'
import coinSpinning41  from '../assets/images/newCoinspin/41.png'
import coinSpinning42  from '../assets/images/newCoinspin/42.png'
import coinSpinning43  from '../assets/images/newCoinspin/43.png'
import coinSpinning44  from '../assets/images/newCoinspin/44.png'
import coinSpinning45  from '../assets/images/newCoinspin/45.png'
import coinSpinning46  from '../assets/images/newCoinspin/46.png'
import coinSpinning47  from '../assets/images/newCoinspin/47.png'
import coinSpinning48  from '../assets/images/newCoinspin/48.png'
import coinSpinning49  from '../assets/images/newCoinspin/49.png'
import coinSpinning50  from '../assets/images/newCoinspin/50.png'
import coinSpinning51  from '../assets/images/newCoinspin/51.png'
import coinSpinning52  from '../assets/images/newCoinspin/52.png'
import coinSpinning53  from '../assets/images/newCoinspin/53.png'
import coinSpinning54  from '../assets/images/newCoinspin/54.png'
import coinSpinning55  from '../assets/images/newCoinspin/55.png'
import coinSpinning56  from '../assets/images/newCoinspin/56.png'
import coinSpinning57  from '../assets/images/newCoinspin/57.png'
import coinSpinning58  from '../assets/images/newCoinspin/58.png'
import coinSpinning59  from '../assets/images/newCoinspin/59.png'
import coinSpinning60  from '../assets/images/newCoinspin/60.png'
import coinSpinning61  from '../assets/images/newCoinspin/61.png'
import coinSpinning62  from '../assets/images/newCoinspin/62.png'
import coinSpinning63  from '../assets/images/newCoinspin/63.png'
import coinSpinning64  from '../assets/images/newCoinspin/64.png'
import coinSpinning65  from '../assets/images/newCoinspin/65.png'
import coinSpinning66  from '../assets/images/newCoinspin/66.png'
import coinSpinning67  from '../assets/images/newCoinspin/67.png'
import coinSpinning68  from '../assets/images/newCoinspin/68.png'
import coinSpinning69  from '../assets/images/newCoinspin/69.png'
import coinSpinning70  from '../assets/images/newCoinspin/70.png'
import coinSpinning71  from '../assets/images/newCoinspin/71.png'
import coinSpinning72  from '../assets/images/newCoinspin/72.png'
import coinSpinning73  from '../assets/images/newCoinspin/73.png'
import coinSpinning74  from '../assets/images/newCoinspin/74.png'
import coinSpinning75  from '../assets/images/newCoinspin/75.png'
import coinSpinning76  from '../assets/images/newCoinspin/76.png'
import coinSpinning77  from '../assets/images/newCoinspin/77.png'
import coinSpinning78  from '../assets/images/newCoinspin/78.png'
import coinSpinning79  from '../assets/images/newCoinspin/79.png'
import coinSpinning80  from '../assets/images/newCoinspin/80.png'
import coinSpinning81  from '../assets/images/newCoinspin/81.png'
import coinSpinning82  from '../assets/images/newCoinspin/82.png'
import coinSpinning83  from '../assets/images/newCoinspin/83.png'
import coinSpinning84  from '../assets/images/newCoinspin/84.png'
import coinSpinning85  from '../assets/images/newCoinspin/85.png'
import coinSpinning86  from '../assets/images/newCoinspin/86.png'
import coinSpinning87  from '../assets/images/newCoinspin/87.png'
import coinSpinning88  from '../assets/images/newCoinspin/88.png'
import coinSpinning89  from '../assets/images/newCoinspin/89.png'
import coinSpinning90  from '../assets/images/newCoinspin/90.png'
import coinSpinning91  from '../assets/images/newCoinspin/91.png'
import coinSpinning92  from '../assets/images/newCoinspin/92.png'
import coinSpinning93  from '../assets/images/newCoinspin/93.png'
import coinSpinning94  from '../assets/images/newCoinspin/94.png'
import coinSpinning95  from '../assets/images/newCoinspin/95.png'
import coinSpinning96  from '../assets/images/newCoinspin/96.png'
import coinSpinning97  from '../assets/images/newCoinspin/97.png'
import coinSpinning98  from '../assets/images/newCoinspin/98.png'
import coinSpinning99  from '../assets/images/newCoinspin/99.png'
import coinSpinning100 from '../assets/images/newCoinspin/100.png'
import coinSpinning101 from '../assets/images/newCoinspin/101.png'
import coinSpinning102 from '../assets/images/newCoinspin/102.png'
import coinSpinning103 from '../assets/images/newCoinspin/103.png'
import coinSpinning104 from '../assets/images/newCoinspin/104.png'
import coinSpinning105 from '../assets/images/newCoinspin/105.png'
import coinSpinning106 from '../assets/images/newCoinspin/106.png'
import coinSpinning107 from '../assets/images/newCoinspin/107.png'
import coinSpinning108 from '../assets/images/newCoinspin/108.png'
import coinSpinning109 from '../assets/images/newCoinspin/109.png'
import coinSpinning110 from '../assets/images/newCoinspin/110.png'
import coinSpinning111 from '../assets/images/newCoinspin/111.png'
import coinSpinning112 from '../assets/images/newCoinspin/112.png'
import coinSpinning113 from '../assets/images/newCoinspin/113.png'
import coinSpinning114 from '../assets/images/newCoinspin/114.png'
import coinSpinning115 from '../assets/images/newCoinspin/115.png'
import coinSpinning116 from '../assets/images/newCoinspin/116.png'
import coinSpinning117 from '../assets/images/newCoinspin/117.png'
import coinSpinning118 from '../assets/images/newCoinspin/118.png'
import coinSpinning119 from '../assets/images/newCoinspin/119.png'
import coinSpinning120 from '../assets/images/newCoinspin/120.png'
import coinSpinning121 from '../assets/images/newCoinspin/121.png'

export const coinExplosionPngs = [
    coinExplosion1, 
    coinExplosion2, 
    coinExplosion3, 
    coinExplosion4, 
    coinExplosion5, 
    coinExplosion6, 
    coinExplosion7, 
    coinExplosion8, 
    coinExplosion9, 
    coinExplosion10,
    coinExplosion11,
    coinExplosion12,
    coinExplosion13,
    coinExplosion14,
    coinExplosion15,
    coinExplosion16,
    coinExplosion17,
    coinExplosion18,
    coinExplosion19,
    coinExplosion20,
    coinExplosion21,
    coinExplosion22,
    coinExplosion23,
    coinExplosion24,
    coinExplosion25,
    coinExplosion26,
    coinExplosion27,
    coinExplosion28,
    coinExplosion29,
    coinExplosion30,
    coinExplosion31,
    coinExplosion32,
    coinExplosion33,
    coinExplosion34,
    coinExplosion35,
    coinExplosion36,
    coinExplosion37
]

export const coinSpinningPngs = [
    coinSpinning1, 
    coinSpinning2, 
    coinSpinning3, 
    coinSpinning4, 
    coinSpinning5, 
    coinSpinning6, 
    coinSpinning7, 
    coinSpinning8, 
    coinSpinning9, 
    coinSpinning10,
    coinSpinning11,
    coinSpinning12,
    coinSpinning13,
    coinSpinning14,
    coinSpinning15,
    coinSpinning16,
    coinSpinning17,
    coinSpinning18,
    coinSpinning19,
    coinSpinning20,
    coinSpinning21,
    coinSpinning22,
    coinSpinning23,
    coinSpinning24,
    coinSpinning25,
    coinSpinning26,
    coinSpinning27,
    coinSpinning28,
    coinSpinning29,
    coinSpinning30,
    coinSpinning31,
    coinSpinning32,
    coinSpinning33,
    coinSpinning34,
    coinSpinning35,
    coinSpinning36,
    coinSpinning37,
    coinSpinning38,
    coinSpinning39,
    coinSpinning40,
    coinSpinning41,
    coinSpinning42,
    coinSpinning43,
    coinSpinning44,
    coinSpinning45,
    coinSpinning46,
    coinSpinning47,
    coinSpinning48,
    coinSpinning49,
    coinSpinning50,
    coinSpinning51,
    coinSpinning52,
    coinSpinning53,
    coinSpinning54,
    coinSpinning55,
    coinSpinning56,
    coinSpinning57,
    coinSpinning58,
    coinSpinning59,
    coinSpinning60,
    coinSpinning61,
    coinSpinning62,
    coinSpinning63,
    coinSpinning64,
    coinSpinning65,
    coinSpinning66,
    coinSpinning67,
    coinSpinning68,
    coinSpinning69,
    coinSpinning70,
    coinSpinning71,
    coinSpinning72,
    coinSpinning73,
    coinSpinning74,
    coinSpinning75,
    coinSpinning76,
    coinSpinning77,
    coinSpinning78,
    coinSpinning79,
    coinSpinning80,
    coinSpinning81,
    coinSpinning82,
    coinSpinning83,
    coinSpinning84,
    coinSpinning85,
    coinSpinning86,
    coinSpinning87,
    coinSpinning88,
    coinSpinning89,
    coinSpinning90,
    coinSpinning91,
    coinSpinning92,
    coinSpinning93,
    coinSpinning94,
    coinSpinning95,
    coinSpinning96,
    coinSpinning97,
    coinSpinning98,
    coinSpinning99,
    coinSpinning100,
    coinSpinning101,
    coinSpinning102,
    coinSpinning103,
    coinSpinning104,
    coinSpinning105,
    coinSpinning106,
    coinSpinning107,
    coinSpinning108,
    coinSpinning109,
    coinSpinning110,
    coinSpinning111,
    coinSpinning112,
    coinSpinning113,
    coinSpinning114,
    coinSpinning115,
    coinSpinning116,
    coinSpinning117,
    coinSpinning118,
    coinSpinning119,
    coinSpinning120,
    coinSpinning121
]

export const explosionPngs = [
    explosion1, 
    explosion2, 
    explosion3, 
    explosion4, 
    explosion5, 
    explosion6, 
    explosion7, 
    explosion8, 
    explosion9, 
    explosion10,
    explosion11,
    explosion12,
    explosion13,
    explosion14,
    explosion15,
    explosion16,
    explosion17,
    explosion18,
    explosion19,
    explosion20,
    explosion21,
    explosion22,
    explosion23,
    explosion24,
    explosion25,
    explosion26,
    explosion27,
    explosion28,
    explosion29,
    explosion30,
    explosion31,
    explosion32,
    explosion33,
    explosion34,
    explosion35,
    explosion36,
    explosion37,
    explosion38,
    explosion39,
    explosion40,
    explosion41,
    explosion42,
    explosion43,
    explosion44,
    explosion45,
    explosion46,
    explosion47,
    explosion48,
    explosion49,
    explosion50,
    explosion51,
    explosion52,
    explosion53,
    explosion54,
    explosion55,
    explosion56,
    explosion57,
    explosion58,
    explosion59,
    explosion60,
    explosion61,
    explosion62,
    explosion63,
    explosion64,
    explosion65,
    explosion66,
    explosion67,
    explosion68,
    explosion69,
    explosion70,
    explosion71,
    explosion72,
    explosion73,
    explosion74,
    explosion75,
    explosion76,
    explosion77,
    explosion78,
    explosion79,
    explosion80,
    explosion81,
    explosion82,
    explosion83,
    explosion84,
    explosion85,
    explosion86,
    explosion87,
    explosion88,
    explosion89,
    explosion90,
    explosion91,
    explosion92,
    explosion93,
    explosion94,
    explosion95,
    explosion96,
    explosion97,
    explosion98,
    explosion99,
    explosion100,
    explosion101,
    explosion102,
    explosion103,
    explosion104,
    explosion105,
    explosion106,
    explosion107,
    explosion108,
    explosion109,
    explosion110,
    explosion111,
    explosion112,
    explosion113,
    explosion114,
    explosion115,
    explosion116,
    explosion117,
    explosion118,
    explosion119,
    explosion120,
    explosion121,
    explosion122,
    explosion123,
    explosion124,
    explosion125,
    explosion126,
    explosion127,
    explosion128,
    explosion129,
    explosion130,
    explosion131,
    explosion132,
    explosion133,
    explosion134,
    explosion135,
    explosion136,
    explosion137,
    explosion138,
    explosion139,
    explosion140,
    explosion141,
    explosion142,
    explosion143,
    explosion144,
    explosion145,
    explosion146,
    explosion147,
    explosion148,
    explosion149,
    explosion150,
    explosion151,
    explosion152,
    explosion153,
    explosion154,
    explosion155,
    explosion156,
    explosion157,
    explosion158,
    explosion159,
    explosion160,
    explosion161,
    explosion162,
    explosion163,
    explosion164,
    explosion165,
    explosion166,
    explosion167,
    explosion168
]

export const rocketPngs = [
    rocket1, 
    rocket2, 
    rocket3, 
    rocket4, 
    rocket5, 
    rocket6, 
    rocket7, 
    rocket8, 
    rocket9, 
    rocket10,
    rocket11,
    rocket12,
    rocket13,
    rocket14,
    rocket15,
    rocket16,
    rocket17,
    rocket18,
    rocket19,
    rocket20,
    rocket21,
    rocket22,
    rocket23,
    rocket24,
    rocket25,
    rocket26,
    rocket27,
    rocket28,
    rocket29,
    rocket30,
    // rocket31,
    // rocket32,
    // rocket33,
    // rocket34,
    // rocket35,
    // rocket36,
    // rocket37,
    // rocket38,
    // rocket39,
    // rocket40,
    // rocket41,
    // rocket42,
    // rocket43,
    // rocket44,
    // rocket45,
    // rocket46,
    // rocket47,
    // rocket48,
    // rocket49,
    // rocket50,
    // rocket51,
    // rocket52,
    // rocket53,
    // rocket54,
    // rocket55,
    // rocket56,
    // rocket57,
    // rocket58,
    // rocket59,
    // rocket60
]