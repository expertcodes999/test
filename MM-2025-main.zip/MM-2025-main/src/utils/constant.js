//export const serverUrl = 'https://xcvxcvbxcvuxlaie69l54dfgdvukxevbgugcxv478m.mooncrash.com/';
export const serverUrl = './';
export const tokenIDs = {
    BNB: 1,
    BUSD: 2,
    USDT: 3
}
export const withdrawTokenIDs = {
    BNB: 1
}
export const nextVersion = false;
export const passwordResetWalletAddress = "0x85c46e3f01168608bdc3d5e3c9844ce672b362ef"

export const bnbMultiByBits = 10000123123123123